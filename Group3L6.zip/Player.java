public class Player {
    /* Represents array of dice. */
    private Die [] dice;
    
    /* Represents points the player has accumulated. */
    private int points;

    /**
	  * Constructor - creates a new player object with an array of 3 die.
	  */
    public Player() {
        dice = new Die[3];
        for (int i = 0; i < dice.length; i++) {
            dice[i] = new Die(6);
        }
    }

    /**
	  * Returns the players score.
	  * @return int points
	  */
    public int getPoints() {
        return points;
    }

    /**
	  * Sorts the array of die in ascending order.
	  */
    public void sort() {
        Die d;
        if (dice[1].lessThan(dice[0])) {
            d = dice[0];
            dice[0] = dice[1];
            dice[1] = d;
        }
        if (dice[2].lessThan(dice[0])) {
            d = dice[0];
            dice[0] = dice[2];
            dice[2] = d;
        }
        if (dice[2].lessThan(dice[1])) {
            d = dice[1];
            dice[1] = dice[2];
            dice[2] = d;
        }
    }

    /**
	  * Checks to see if there is a pair of die.
	  * @return boolean, true if there is a pair false if not.
	  */
    public boolean pair() {
        if (dice[0].equals(dice[1])) {
            points++;
            return true;
        }
        if (dice[0].equals(dice[2])) {
            points++;
            return true;
        }
        if (dice[1].equals(dice[2])) {
            points++;
            return true;
        }
        return false;
    }

    /**
	  * Checks to see if there is a three of a kind of a die.
	  * @return boolean, true if there is a three of a kind, false otherwise.
	  */
    public boolean threeOfAKind() {
        if (dice[0].equals(dice[1]) && dice[0].equals(dice[2])) {
            points += 3;
            return true;
        }
        return false;
    }

    /**
	  * Checks to see if there is a series of die.
	  * @return boolean, true if there is a series, false otherwise.
	  */
    public boolean series() {
        if (dice[0].difference(dice[1]) == -1 && dice[1].difference(dice[2]) == -1) {
            points += 2;
            return true;
        }
        return false;
    }

    /**
	  * Rolls each dice for a value and calls the sort method.
	  */
    public void roll() {
        for (Die die : dice) {
            die.roll();
        }
        sort();
    }

    /**
	  * Creates a defaulted string when a player object is printed.
	  * @return string of the values of each dice.
	  */
    public String toString() {
        StringBuilder s = new StringBuilder();
        for( int d = 0; d < dice.length; d++ ) {
            s.append("D").append(d + 1).append("=").append(dice[d]).append(", ");
        }
        return s.toString();
    }
}
