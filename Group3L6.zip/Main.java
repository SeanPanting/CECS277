/*
 * Joe Brasher, Sean Panting
 * 
 * September 29, 2021
 * 
 * A program that creates a dice game similar to Yahtzee, using a Player object as well as a Die object. Three dice are rolled, if they are in a series the user recieves 2 points, if a pair, the user gets one point and three points for a triple. The user's score is tallied until the user decides to quit.
 */

 public class Main {
    public static void main(String[] args) {
        Player p = new Player();
        boolean go = true;

        System.out.println("Yahtzee\n");
        while (go) {
            takeTurn(p);
            System.out.println("Play again? (Y/N) ");
            go = CheckInput.getYesNo();
            System.out.println("");
        }

        System.out.println("Game Over.");
        System.out.println("Final Score = " + p.getPoints() + " points");
    }

    /**
	  * First rolls Player p's dice.
    * Second checks if the player got a three of a kind, a pair, or a series.
    * Lastly prints out the player's updated score.
	  * @param Player p object
	  */
    public static void takeTurn(Player p) {
        p.roll();
        System.out.println("Rolling Dice..." + p);
        
        if (p.threeOfAKind()) {
            System.out.println("You got a 3 of a kind!");
        }
        else if (p.pair()) {
            System.out.println("You got a pair!");
        }
        else if (p.series()) {
            System.out.println("You got a series of 3!");
        }
        else {
            System.out.println("Aww. Too Bad.");
        }
        
        System.out.println("Score = " + p.getPoints() + " points.");
    }
}
