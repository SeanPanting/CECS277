public class Die{

  /* Represents number of sides of this die */
  private int sides;

  /* Represents the value of this die. */
  private int value;

    /** Constructor - assign the number of sides from the value passed in. Set value
    * to 0.
    * @param s sets the number of sides of this die
    */
  public Die( int s ){
    sides = s;
    value = 0;
  }

     /** Rolls the die
    *  @return the die's value
    */
  public int roll(){
    value = (int) (Math.random() * sides) + 1;
    return value;
  }

     /** Tests to see if value and sides are equal
    * @param o object to compare to this Die object
    * @return true if the both objects have equal sides and values
    */
  @Override
  public boolean equals(Object o){
    if(o instanceof Die ){
      Die d = (Die) o;
          return sides == d.sides && value == d.value;
    }
    return false;
  }

     /** Tests to see implicit die is less than the explicit die
    * @param Die d(explicit die)
    * @return true if implicit die is less than explicit die
    */
  public boolean lessThan(Die d){
    return value < d.value;
  }

     /** Finds the difference between the implicit and explicit dice values
    * @param Die d(explicit Die)
    * @return difference between implicit and explicit die values
    */
  public int difference(Die d){
    return value - d.value;
  }

    /** String representation of a Die object
     *  @return string representation of this Die
     */
  @Override
  public String toString(){
    return "" + value;
  }
}